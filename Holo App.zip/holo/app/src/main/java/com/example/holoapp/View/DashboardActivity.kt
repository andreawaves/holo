package com.example.holoapp.View

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.holoapp.R

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
    }
}
